#include <iostream>
#include <time.h>

using namespace std;

class CCoin
{
private:
	int sideup;
public:
	CCoin()
	{
		sideup = 0;
	}

	void flip()
	{
		sideup = rand() % 2;
	}

	int GiveMeSideup()
	{
		return sideup;
	}

};

//void flip(int & thecoin)
//{
//	
//	thecoin = rand() % 2;
//}

void main()
{
	srand(time(NULL));
	int age = 42;
	/*int coin1 = 0;

	flip(age);
	for (int x = 0; x < 10000; x++)
	{
		flip(coin1);
		cout << coin1 << endl;
	}*/


	CCoin c1;
	c1.flip();
	if (c1.GiveMeSideup() == 0)
	{
		cout << "heads" << endl;
	}
	else
	{
		cout << "Tails" << endl;
	}
	CCoin c2;
	c2.flip();
	//c2.flip(age);
	//c2.sideup = 42;


	system("pause");

}